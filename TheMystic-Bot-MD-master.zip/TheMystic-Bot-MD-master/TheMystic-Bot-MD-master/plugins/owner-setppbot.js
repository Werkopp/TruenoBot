function _0x31ac(_0x16c31d, _0x391554) {
  const _0x14c2c6=_0x14c2(); return _0x31ac=function(_0x31ac59, _0x41e1db) {
    _0x31ac59=_0x31ac59-0x1b1; const _0x1c6184=_0x14c2c6[_0x31ac59]; return _0x1c6184;
  }, _0x31ac(_0x16c31d, _0x391554);
} const _0x34771d=_0x31ac; (function(_0x8d3321, _0x5019dd) {
  const _0x36e927=_0x31ac; const _0x211e28=_0x8d3321(); while ([]) {
    try {
      const _0x500528=parseInt(_0x36e927(0x1ca))/0x1+-parseInt(_0x36e927(0x1b4))/0x2+-parseInt(_0x36e927(0x1b9))/0x3+parseInt(_0x36e927(0x1c3))/0x4*(-parseInt(_0x36e927(0x1b6))/0x5)+-parseInt(_0x36e927(0x1cc))/0x6*(-parseInt(_0x36e927(0x1cd))/0x7)+parseInt(_0x36e927(0x1d0))/0x8*(parseInt(_0x36e927(0x1ce))/0x9)+-parseInt(_0x36e927(0x1bd))/0xa*(-parseInt(_0x36e927(0x1b5))/0xb); if (_0x500528===_0x5019dd) break; else _0x211e28['push'](_0x211e28['shift']());
    } catch (_0x9b5c64) {
      _0x211e28['push'](_0x211e28['shift']());
    }
  }
}(_0x14c2, 0xb4aad)); import _0x29cf90 from 'jimp'; const handler=async (_0x55976e, {conn: _0x14ced5, usedPrefix: _0x33d1e6, command: _0x480711, args: _0x4bb196, isOwner: _0x5a3d5e, isAdmin: _0x1410d6, isROwner: _0x18371c})=>{
  const _0x2359c0=_0x31ac; try {
    const _0x2538c6=_0x14ced5[_0x2359c0(0x1c2)][_0x2359c0(0x1b2)]; const _0xf17176=_0x55976e[_0x2359c0(0x1bb)]?_0x55976e['quoted']:_0x55976e; if (!_0x55976e[_0x2359c0(0x1bb)]) throw '*[❗𝐈𝐍𝐅𝐎❗]\x20𝙽𝙾\x20𝚂𝙴\x20𝙴𝙽𝙲𝙾𝙽𝚃𝚁𝙾\x20𝙻𝙰\x20𝙸𝙼𝙰𝙶𝙴𝙽,\x20𝙿𝙾𝚁\x20𝙵𝙰𝚅𝙾𝚁\x20𝚁𝙴𝚂𝙿𝙾𝙽𝙳𝙴\x20𝙰\x20𝚄𝙽𝙰\x20𝙸𝙼𝙰𝙶𝙴𝙽\x20𝚄𝚂𝙰𝙽𝙳𝙾\x20𝙴𝙻\x20𝙲𝙾𝙼𝙰𝙽𝙳𝙾\x20'+(_0x33d1e6+_0x480711)+'*'; const _0x353a82=(_0xf17176[_0x2359c0(0x1b1)]||_0xf17176)[_0x2359c0(0x1cf)]||''; const _0x434471=await _0xf17176[_0x2359c0(0x1ba)](); const _0x3aeaf4=await _0x2538c6; async function _0x4d2c5f(_0x2e4ee1) {
      const _0x398c4c=_0x2359c0; const _0x5e6130=await _0x29cf90[_0x398c4c(0x1c9)](_0x2e4ee1); const _0x1347f7=_0x5e6130[_0x398c4c(0x1b7)]()>_0x5e6130[_0x398c4c(0x1c4)]()?_0x5e6130['resize'](0x2d0, _0x29cf90[_0x398c4c(0x1c1)]):_0x5e6130[_0x398c4c(0x1be)](_0x29cf90[_0x398c4c(0x1c1)], 0x2d0); const _0x17aa09=await _0x29cf90[_0x398c4c(0x1c9)](await _0x1347f7[_0x398c4c(0x1c5)](_0x29cf90[_0x398c4c(0x1cb)])); return {'img': await _0x1347f7[_0x398c4c(0x1c5)](_0x29cf90[_0x398c4c(0x1cb)])};
    } const {img: _0x35d6f3}=await _0x4d2c5f(_0x434471); await _0x14ced5[_0x2359c0(0x1bc)]({'tag': 'iq', 'attrs': {'to': _0x3aeaf4, 'type': 'set', 'xmlns': _0x2359c0(0x1c6)}, 'content': [{'tag': _0x2359c0(0x1c8), 'attrs': {'type': _0x2359c0(0x1b3)}, 'content': _0x35d6f3}]}), _0x55976e[_0x2359c0(0x1b8)](_0x2359c0(0x1c7));
  } catch {
    throw _0x2359c0(0x1bf)+(_0x33d1e6+_0x480711)+'*';
  }
}; handler['command']=/^setppbot$/i, handler[_0x34771d(0x1c0)]=!![]; export default handler; function _0x14c2() {
  const _0x1897e4=['AUTO', 'user', '8CJixwu', 'getHeight', 'getBufferAsync', 'w:profile:picture', '*[❗𝐈𝐍𝐅𝐎❗]\x20𝚂𝙴\x20𝙲𝙰𝙼𝙱𝙸𝙾\x20𝙲𝙾𝙽\x20𝙴𝚇𝙸𝚃𝙾\x20𝙻𝙰\x20𝙵𝙾𝚃𝙾\x20𝙳𝙴\x20𝙿𝙴𝚁𝙵𝙸𝙻\x20𝙳𝙴𝙻\x20𝙽𝚄𝙼𝙴𝚁𝙾\x20𝙳𝙴𝙻\x20𝙱𝙾𝚃*', 'picture', 'read', '1419731ZjYevm', 'MIME_JPEG', '82272azbcaw', '350agtQLJ', '279gQMikZ', 'mimetype', '188728rlRvtO', 'msg', 'jid', 'image', '1705364hxGRFM', '14905ZvBfug', '2578255zmHnCy', 'getWidth', 'reply', '1780230pdlTpE', 'download', 'quoted', 'query', '2810ZHRQDi', 'resize', '*[❗𝐈𝐍𝐅𝐎❗]\x20𝙽𝙾\x20𝚂𝙴\x20𝙴𝙽𝙲𝙾𝙽𝚃𝚁𝙾\x20𝙻𝙰\x20𝙸𝙼𝙰𝙶𝙴𝙽,\x20𝙿𝙾𝚁\x20𝙵𝙰𝚅𝙾𝚁\x20𝚁𝙴𝚂𝙿𝙾𝙽𝙳𝙴\x20𝙰\x20𝚄𝙽𝙰\x20𝙸𝙼𝙰𝙶𝙴𝙽\x20𝚄𝚂𝙰𝙽𝙳𝙾\x20𝙴𝙻\x20𝙲𝙾𝙼𝙰𝙽𝙳𝙾\x20', 'rowner']; _0x14c2=function() {
    return _0x1897e4;
  }; return _0x14c2();
}

/* let handler = async (m, { conn, usedPrefix, command }) => {
let bot = conn.user.jid
let q = m.quoted ? m.quoted : m
let mime = (q.msg || q).mimetype || ''
if (/image/.test(mime)) {
let img = await q.download()
if (!img) throw `*[❗𝐈𝐍𝐅𝐎❗] 𝙽𝙾 𝚂𝙴 𝙴𝙽𝙲𝙾𝙽𝚃𝚁𝙾 𝙻𝙰 𝙸𝙼𝙰𝙶𝙴𝙽, 𝙿𝙾𝚁 𝙵𝙰𝚅𝙾𝚁 𝚁𝙴𝚂𝙿𝙾𝙽𝙳𝙴 𝙰 𝚄𝙽𝙰 𝙸𝙼𝙰𝙶𝙴𝙽 𝚄𝚂𝙰𝙽𝙳𝙾 𝙴𝙻 𝙲𝙾𝙼𝙰𝙽𝙳𝙾 ${usedPrefix + command}*`
await conn.updateProfilePicture(bot, img)
conn.reply(m.chat, '*[❗𝐈𝐍𝐅𝐎❗] 𝚂𝙴 𝙲𝙰𝙼𝙱𝙸𝙾 𝙲𝙾𝙽 𝙴𝚇𝙸𝚃𝙾 𝙻𝙰 𝙵𝙾𝚃𝙾 𝙳𝙴 𝙿𝙴𝚁𝙵𝙸𝙻 𝙳𝙴𝙻 𝙽𝚄𝙼𝙴𝚁𝙾 𝙳𝙴𝙻 𝙱𝙾𝚃*', m)
} else throw `*[❗𝐈𝐍𝐅𝐎❗] 𝙽𝙾 𝚂𝙴 𝙴𝙽𝙲𝙾𝙽𝚃𝚁𝙾 𝙻𝙰 𝙸𝙼𝙰𝙶𝙴𝙽, 𝙿𝙾𝚁 𝙵𝙰𝚅𝙾𝚁 𝚁𝙴𝚂𝙿𝙾𝙽𝙳𝙴 𝙰 𝚄𝙽𝙰 𝙸𝙼𝙰𝙶𝙴𝙽 𝚄𝚂𝙰𝙽𝙳𝙾 𝙴𝙻 𝙲𝙾𝙼𝙰𝙽𝙳𝙾 ${usedPrefix + command}*`}
handler.command = /^setppbot$/i
handler.rowner = true
export default handler*/
